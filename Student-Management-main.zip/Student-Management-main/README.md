# Student-Management
<br>

<strong>Technologies Used:</strong><br>
Java 17<br>
Spring Boot<br>
Spring MVC<br>
MySQL<br>

The Login UserName and Password <br>
  <strong>userName:</strong>admin<br>
  <strong>password:</strong>admin123<br><br>
![Screenshot (28)](https://github.com/user-attachments/assets/eab70de2-5562-4984-93f5-ce85a17257ed)
<br>
![Screenshot (32)](https://github.com/user-attachments/assets/fe32470f-cfaf-47b2-8415-0135c062e41e)
![Screenshot (27)](https://github.com/user-attachments/assets/7911f037-7b9d-48ce-bc4e-a5025f471414)





